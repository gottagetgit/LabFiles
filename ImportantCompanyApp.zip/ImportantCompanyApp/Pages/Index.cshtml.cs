﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ImportantCompanyApp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        public string WriteMessage { get; private set; } = "";

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnPost()
        {
            GoWriteMessage();
        }

        public void GoWriteMessage()
        {
            WriteMessage += "Message written: Hello, Azure!\n";
        }

        public void OnGetGoReadMessage()
        {
            WriteMessage += "No messages found";
        }

    }
}
